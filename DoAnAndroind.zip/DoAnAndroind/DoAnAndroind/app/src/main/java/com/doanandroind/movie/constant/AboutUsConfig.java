package com.doanandroind.movie.constant;

public interface AboutUsConfig {
    String ABOUT_US_TITLE = "Orange TV";
    String ABOUT_US_SLOGAN = "Khám phá thế giới phim ngay bây giờ";
}
